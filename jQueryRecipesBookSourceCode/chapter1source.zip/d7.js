$(document).ready(function() {
  alert($('p').html());
});