$('p').prepend('<h2> Power of selectors </h2>');
$('p').addClass('highlight');
