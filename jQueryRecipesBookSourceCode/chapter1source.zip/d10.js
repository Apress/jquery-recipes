$('.features').addClass('highlight');
