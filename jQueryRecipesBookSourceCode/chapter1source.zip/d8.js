$(document).ready(function() {
  $('h2').text('JavaScript Libraries');
});