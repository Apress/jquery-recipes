$(document).ready(function() {   
  $('p.feature').addClass('greencolor');
  $('p.feature span').addClass('highlight');
});