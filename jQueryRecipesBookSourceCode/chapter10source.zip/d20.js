$(document).ready(function() {
  $('span').css({'background':'url(shadowright.jpg)',  'background-repeat':'no-repeat','background-position':'bottom right', 'padding':'0 10px 0 0'});
  $('img').css({'width':'200px','height':'200px','background':'url(shadowbottom.jpg)',  'background-repeat':'no-repeat','background-position':'bottom', 'padding':'0 0 10px 0' });
});
