$(document).ready(function() {
  $('.leftalign').css({'position':'absolute', 'left':'50px', 'width':'300px'});
  $('.centeralign').css({'position':'absolute', 'left':'400px', 'width':'300px'});
  $('.rightalign').css({'position':'absolute', 'left':'750px', 'width':'300px'});
});
