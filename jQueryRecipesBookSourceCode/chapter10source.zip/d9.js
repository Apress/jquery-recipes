$(document).ready(function() {
  $('p.feature').addClass('quote');
  $('div').addClass('closing');
});