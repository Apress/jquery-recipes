$(document).ready(function() {
  $('img').wrap('<div></div>');
  $('<p>Styles make the formatting job much easier and efficient. To give an attractive look to web sites, styles are heavily used. A person must have a good knowledge of HTML and CSS and a bit of Javascript. jQuery is a powerful JavaScript library that allows us to add dynamic elements to our web sites. Not only it is easy to learn but easy to implement too.  jQuery is an open source project that provides a wide range of features with cross platform compatiblity. jQuery has hundreds of plug-ins to extend its features. JQuery helps in increasing interactions with a web site. </p>').appendTo('div');
  $('img').css({'float':'left',  'width':'200px','height':'200px'});
  $('p').css({'clear':'right'});
});