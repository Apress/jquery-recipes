$(document).ready(function() {
  $('p').addClass('firstindent');
});