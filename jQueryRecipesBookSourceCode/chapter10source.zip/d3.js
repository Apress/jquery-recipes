$(document).ready(function() {
  $('span.cap').addClass('initialcap');
});