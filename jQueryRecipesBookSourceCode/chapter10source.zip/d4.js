$(document).ready(function() {
  $('h3').addClass('heading');
});
