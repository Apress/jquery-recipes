$('p').css({'width':'50%','height':'100px','overflow':'scroll'});
