$(document).ready(function() {
  $('p.feature').addClass('quote');
});