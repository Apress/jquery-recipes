$(document).ready(function() {
  $('ul').addClass('liststyle');
  $('li').addClass('liststyle');
});