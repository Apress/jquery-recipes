$(document).ready(function() {
$('img').addClass('moveleft');
$('p').addClass('imagewrap');
});