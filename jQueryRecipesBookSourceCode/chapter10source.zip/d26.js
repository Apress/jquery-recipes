$(document).ready(function() {
  $('body').addClass('placeimage');
});