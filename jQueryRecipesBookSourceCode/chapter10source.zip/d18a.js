$(document).ready(function() {
  $('p').css({'float':'left',  'width':'300px','margin':'5px'});
});