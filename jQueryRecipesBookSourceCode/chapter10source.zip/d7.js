$(document).ready(function() {
  $('p').addClass('hangingindent');
});