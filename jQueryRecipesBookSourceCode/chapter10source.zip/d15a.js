$(document).ready(function() {
  $('a[@href^="mailto:"]').addClass('linkstyle');
});