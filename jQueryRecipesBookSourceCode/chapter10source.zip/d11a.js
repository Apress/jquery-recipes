$(document).ready(function() {
  $('#drink >li').addClass('highlight');
});