$(document).ready(function() {
$('a[@href]').addClass('linkstyle');
});