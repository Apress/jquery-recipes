$(document).ready(function() {
  $('p').addClass('backfig');
});