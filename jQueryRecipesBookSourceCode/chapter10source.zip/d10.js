$(document).ready(function() {   
  $('li').addClass('dispdisc');
});
