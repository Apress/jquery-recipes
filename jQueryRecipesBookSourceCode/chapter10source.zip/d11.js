$(document).ready(function() {   
  $('#intro').addClass('dispdisc');
});