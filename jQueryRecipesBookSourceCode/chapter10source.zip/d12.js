
$(document).ready(function() {
  $('ul').addClass('liststyle');
  $('li').addClass('applytopborders');
  $('li:last').addClass('applybottomborder');
});

