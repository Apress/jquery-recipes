$(document).ready(function() {
  $('div').click(function(event){
    alert('You have clicked the div element');
  });

  $('p').click(function(event){
    alert('You have clicked the paragraph element');
  });

  $('span').click(function(event){
    alert('You have clicked the span element');
  });
});