$(document).ready(function() {
  $('<a href="#topofpage">Return to top</a>').insertAfter('p');
  $('<a id="topofpage" name="topofpage"></a>').prependTo('body');
});
