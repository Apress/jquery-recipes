$(document).ready(function() {
  $('.name').focus(function(){
    alert('The focus currently is on name field');
  });
});