$(document).ready(function() {
  $('.bold').bind('click', function(){
    alert('You have clicked the Bold button');
  });

  $('.italic').bind('click', function(){
    alert('You have clicked the Italic button');
  });
});