$(document).ready(function() {
  $('.name').blur(function(){
    alert('The focus is lost from name field');
  });
});