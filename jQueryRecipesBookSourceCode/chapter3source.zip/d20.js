$(document).ready(function() {
  $('img').click(function(){
    $(this).animate({left:600}, 'slow')
  });
});
