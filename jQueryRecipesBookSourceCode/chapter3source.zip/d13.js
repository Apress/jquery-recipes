$(document).ready(function() {
$('.add').click(function(){
$('div').prepend('<p>Styles make the formatting job much easier and efficient. To give an attractive look to web sites, styles are heavily used. A person must have a good knowledge of HTML and CSS and a bit of Javascript.  </p>');
});
$('.remove').click(function(){
$('p').remove();
});
});