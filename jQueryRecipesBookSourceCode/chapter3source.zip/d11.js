$(document).ready(function() {
  $('.buttons').click(function(){
    $(this).toggleClass('hover');
  });
});