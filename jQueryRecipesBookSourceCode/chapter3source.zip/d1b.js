$(document).ready(function() {
  $('.buttons').click(function(){
    alert('You have clicked the ' +$(this).text()+' button');
  });
});