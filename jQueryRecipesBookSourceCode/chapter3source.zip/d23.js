$(document).ready(function() {
  $('div').children().clone().prependTo('div').addClass('hover');
});
