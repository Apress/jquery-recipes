$(document).ready(function() {
  $('.buttons').mouseover(function(){
    $('p').css({
      'background-color':'cyan',
      'font-weight':'bold',
      'color':'blue'
    });
  });
});
