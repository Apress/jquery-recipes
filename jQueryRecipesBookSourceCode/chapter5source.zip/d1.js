$(document).ready(function() {
  $('ul').addClass('uliststyle');
  $('ul li ul li').addClass('liststyle');
});
