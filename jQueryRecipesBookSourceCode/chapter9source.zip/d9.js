$(document).ready(function() {   
$('.studrec').tablesorter();
});