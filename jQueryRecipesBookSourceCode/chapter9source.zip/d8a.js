$(document).ready(function() {   
$("#datepicker").datepicker({dateFormat: 'yy-mm-dd'});

});