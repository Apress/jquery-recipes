$(document).ready(function() {   
$("#carousel").html($("#holder_images").html()).carousel3d( {control: 'buttons', centerX: $('#carousel').offset().left + $('#carousel').width()/2 } ); 
});