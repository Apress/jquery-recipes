$(document).ready(function() {   
$('.studrec').dataTable(); 
});