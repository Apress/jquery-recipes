$(document).ready(function() {   
$('.studrec').tableDnD();
});