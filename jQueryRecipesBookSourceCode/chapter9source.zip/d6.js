$(document).ready(function() {   
alert("Width: " +$('.pic').width()+" Height :"+$('.pic').height()+" Inner Width :"+$('.pic').innerWidth());
});