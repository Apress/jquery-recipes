$(document).ready(function() {
  $('.image').click(function (event){ 
    $(this).animate({'left': -160}, 'slow' );
  });
});