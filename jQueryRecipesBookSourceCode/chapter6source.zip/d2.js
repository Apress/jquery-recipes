$(document).ready(function() {
$('#scroller').css({'margin':'auto', 'width':'490px', 'height':'170px', 'overflow':'scroll'});
$('#images').css({'width':'790px'});
});