$(document).ready(function() {   
  $('td:nth-child(odd)').addClass('hover');
});
