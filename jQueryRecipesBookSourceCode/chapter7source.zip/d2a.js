$(document).ready(function() {   
  $('table tr:odd').addClass('hover');
});