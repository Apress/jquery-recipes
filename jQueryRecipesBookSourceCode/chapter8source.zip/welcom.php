<?php   
$name = $_GET['uname'];   
echo "Welcome ".  $name;
?> 