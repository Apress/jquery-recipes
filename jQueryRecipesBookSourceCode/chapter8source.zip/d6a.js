$(document).ready(function() {   
    $('.list').click(function () {           
$('#message').load('namesinfo.htm li');
        return false;   
    });
});