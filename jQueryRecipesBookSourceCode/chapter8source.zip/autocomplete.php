<?php   
echo '<li>Jackub</li>';
echo '<li>Jenny</li>';
echo '<li>Jill</li>';
echo '<li>John</li>';
?>  