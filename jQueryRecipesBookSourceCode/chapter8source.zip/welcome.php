<?php   
$name = $_POST['uname'];   
echo "Welcome ".  $name;
?> 