$(document).ready(function() {   
    $('.list').click(function () {           
$('#message').load('namesinfo.htm');
        return false;   
    });
});